import java.io.*;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.*;

public class Library implements Serializable {
    private static final long serialVersionUID = 1L;
    private static final String DATA_FILE = "library.dat";

    public static final int LOAN_DAYS = 14;
    public static final int FINE_PER_DAY = 5; // Taka
    public static final int MAX_BOOKS_PER_MEMBER = 3;

    private final Map<Integer, Book> books = new LinkedHashMap<>();
    private final Map<Integer, Member> members = new LinkedHashMap<>();
    private int nextBookId = 1;
    private int nextMemberId = 1;

    // ---------- Book ----------
    public Book addBook(String title, String author) {
        Book book = new Book(nextBookId++, title, author);
        books.put(book.getId(), book);
        return book;
    }

    public String removeBook(int bookId) {
        Book book = books.get(bookId);
        if (book == null) return "Book paoa jayni.";
        if (!book.isAvailable()) return "Ei boi ta ekhon issue kora ache, remove kora jabe na.";
        books.remove(bookId);
        return "Book remove kora hoyeche.";
    }

    public List<Book> searchBooks(String keyword) {
        String k = keyword.toLowerCase();
        List<Book> result = new ArrayList<>();
        for (Book b : books.values()) {
            if (b.getTitle().toLowerCase().contains(k) || b.getAuthor().toLowerCase().contains(k)) {
                result.add(b);
            }
        }
        return result;
    }

    public Collection<Book> getAllBooks() { return books.values(); }

    public List<Book> getIssuedBooks() {
        List<Book> result = new ArrayList<>();
        for (Book b : books.values()) if (!b.isAvailable()) result.add(b);
        return result;
    }

    // ---------- Member ----------
    public Member addMember(String name, String phone) {
        Member m = new Member(nextMemberId++, name, phone);
        members.put(m.getId(), m);
        return m;
    }

    public Collection<Member> getAllMembers() { return members.values(); }

    // ---------- Issue / Return ----------
    public String issueBook(int bookId, int memberId) {
        Book book = books.get(bookId);
        Member member = members.get(memberId);

        if (book == null) return "Book paoa jayni.";
        if (member == null) return "Member paoa jayni.";
        if (!book.isAvailable()) return "Boi ta already onno kew nise.";
        if (member.getBorrowedBookIds().size() >= MAX_BOOKS_PER_MEMBER)
            return "Ei member already " + MAX_BOOKS_PER_MEMBER + " ta boi niyeche (limit sesh).";

        LocalDate due = LocalDate.now().plusDays(LOAN_DAYS);
        book.issueTo(memberId, due);
        member.getBorrowedBookIds().add(bookId);
        return "Issue successful! Return date: " + due;
    }

    public String returnBook(int bookId) {
        Book book = books.get(bookId);
        if (book == null) return "Book paoa jayni.";
        if (book.isAvailable()) return "Ei boi ta issue kora chhilo na.";

        Member member = members.get(book.getIssuedToMemberId());
        long daysLate = ChronoUnit.DAYS.between(book.getDueDate(), LocalDate.now());
        long fine = Math.max(0, daysLate) * FINE_PER_DAY;

        if (member != null) member.getBorrowedBookIds().remove(Integer.valueOf(bookId));
        book.markReturned();

        if (fine > 0) {
            return "Return successful. " + daysLate + " din deri hoyeche, fine: " + fine + " Taka.";
        }
        return "Return successful. Kono fine nei.";
    }

    // ---------- Save / Load ----------
    public void save() {
        try (ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            out.writeObject(this);
        } catch (IOException e) {
            System.out.println("Data save korte problem: " + e.getMessage());
        }
    }

    public static Library load() {
        File file = new File(DATA_FILE);
        if (!file.exists()) return new Library();
        try (ObjectInputStream in = new ObjectInputStream(new FileInputStream(file))) {
            return (Library) in.readObject();
        } catch (IOException | ClassNotFoundException e) {
            System.out.println("Purono data load kora jayni, notun library shuru hocche.");
            return new Library();
        }
    }
}
