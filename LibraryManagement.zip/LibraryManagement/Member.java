import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class Member implements Serializable {
    private static final long serialVersionUID = 1L;

    private final int id;
    private String name;
    private String phone;
    private final List<Integer> borrowedBookIds = new ArrayList<>();

    public Member(int id, String name, String phone) {
        this.id = id;
        this.name = name;
        this.phone = phone;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public String getPhone() { return phone; }
    public List<Integer> getBorrowedBookIds() { return borrowedBookIds; }

    @Override
    public String toString() {
        return String.format("[%d] %-20s | Phone: %-15s | Borrowed books: %d",
                id, name, phone, borrowedBookIds.size());
    }
}
