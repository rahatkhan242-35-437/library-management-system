import java.util.Collection;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        Library library = Library.load();
        boolean running = true;

        System.out.println("=== Library Management System ===");

        while (running) {
            printMenu();
            int choice = readInt("Tomar choice: ");
            System.out.println();

            switch (choice) {
                case 1 -> {
                    String title = readLine("Book er naam: ");
                    String author = readLine("Author er naam: ");
                    Book b = library.addBook(title, author);
                    System.out.println("Book add hoyeche. ID: " + b.getId());
                }
                case 2 -> printBooks(library.getAllBooks());
                case 3 -> {
                    String keyword = readLine("Search korbe (naam/author): ");
                    printBooks(library.searchBooks(keyword));
                }
                case 4 -> System.out.println(library.removeBook(readInt("Book ID: ")));
                case 5 -> {
                    String name = readLine("Member er naam: ");
                    String phone = readLine("Phone number: ");
                    Member m = library.addMember(name, phone);
                    System.out.println("Member add hoyeche. ID: " + m.getId());
                }
                case 6 -> {
                    Collection<Member> members = library.getAllMembers();
                    if (members.isEmpty()) System.out.println("Kono member nei.");
                    else members.forEach(System.out::println);
                }
                case 7 -> {
                    int bookId = readInt("Book ID: ");
                    int memberId = readInt("Member ID: ");
                    System.out.println(library.issueBook(bookId, memberId));
                }
                case 8 -> System.out.println(library.returnBook(readInt("Book ID: ")));
                case 9 -> printBooks(library.getIssuedBooks());
                case 0 -> {
                    library.save();
                    System.out.println("Data save hoyeche. Dhonnobad!");
                    running = false;
                }
                default -> System.out.println("Vul choice, abar try koro.");
            }

            if (running) library.save(); // prottek change er por auto-save
        }
    }

    private static void printMenu() {
        System.out.println("\n----------- MENU -----------");
        System.out.println("1. Add Book");
        System.out.println("2. View All Books");
        System.out.println("3. Search Book");
        System.out.println("4. Remove Book");
        System.out.println("5. Add Member");
        System.out.println("6. View All Members");
        System.out.println("7. Issue Book");
        System.out.println("8. Return Book");
        System.out.println("9. View Issued Books");
        System.out.println("0. Save & Exit");
        System.out.println("----------------------------");
    }

    private static void printBooks(Collection<Book> books) {
        if (books.isEmpty()) {
            System.out.println("Kono book paoa jayni.");
            return;
        }
        books.forEach(System.out::println);
    }

    private static String readLine(String prompt) {
        System.out.print(prompt);
        return sc.nextLine().trim();
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Shudhu number din.");
            }
        }
    }
}
