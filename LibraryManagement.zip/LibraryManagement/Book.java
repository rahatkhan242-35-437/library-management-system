import java.io.Serializable;
import java.time.LocalDate;

public class Book implements Serializable {
    private static final long serialVersionUID = 1L;

    private final int id;
    private String title;
    private String author;
    private int issuedToMemberId = -1; // -1 mane kew nei nai
    private LocalDate dueDate;

    public Book(int id, String title, String author) {
        this.id = id;
        this.title = title;
        this.author = author;
    }

    public int getId() { return id; }
    public String getTitle() { return title; }
    public String getAuthor() { return author; }
    public int getIssuedToMemberId() { return issuedToMemberId; }
    public LocalDate getDueDate() { return dueDate; }
    public boolean isAvailable() { return issuedToMemberId == -1; }

    public void issueTo(int memberId, LocalDate dueDate) {
        this.issuedToMemberId = memberId;
        this.dueDate = dueDate;
    }

    public void markReturned() {
        this.issuedToMemberId = -1;
        this.dueDate = null;
    }

    @Override
    public String toString() {
        String status = isAvailable() ? "Available" : "Issued (Member #" + issuedToMemberId + ", Due: " + dueDate + ")";
        return String.format("[%d] %-30s by %-20s | %s", id, title, author, status);
    }
}
